一、Cmd方式
	开发平台: Windows 10
	开发工具：VS2022 x86

二、菜单栏                                                            
------------------------------------------------------------------------------------------
|                                                                                        
|                          欢迎来到         类Unix文件系统                               
|                                                                                        
| [操作说明]:                                                                            
|                                                                                        
| [Order]:help <op_name>                 		[Use]:Order提示                                 
| [Order]:test                          			[Use]:自动测试                                  
|                                                                                       
| [Order]:fformat                        		[Use]:格式化文件系统                            
| [Order]:ls                             			[Use]:查看当前目录内容                          
| [Order]:mkdir <dirname>                		[Use]:生成文件夹                                
| [Order]:cd <dirname>                   		[Use]:进入目录                                  
| [Order]:fcreate <filename>             		[Use]:创建文件名为filename的文件                
| [Order]:fopen <filename>               		[Use]:打开文件名为filename的文件                
| [Order]:fclose <fd>                    		[Use]:关闭文件句柄为fd的文件                   
| [Order]:fread <fd> <outfile> <size>    		[Use]:从fd文件读取size字节，输出到outfile       
| [Order]:fread <fd> std <size>          		[Use]:从fd文件读取size字节，输出到屏幕          
| [Order]:fwrite <fd> <infile> <size>    		[Use]:从infile输入，写入fd文件size字节          
| [Order]:flseek <fd> <step> begin       		[Use]:以begin模式把fd文件指针偏移step           
| [Order]:flseek <fd> <step> cur         		[Use]:以cur模式把fd文件指针偏移step             
| [Order]:flseek <fd> <step> end         		[Use]:以end模式把fd文件指针偏移step             
| [Order]:fdelete <filename>             		[Use]:删除文件文件名为filename的文件或者文件夹  
| [Order]:frename <filename> <filename1> 	[Use]:将文件fliename重命名为filename1           
| [Order]:ftree <dirname>                		[Use]:列出dirname的文件目录树                   
| [Order]:exit                           			[Use]:退出系统，并将缓存内容存至磁盘            
------------------------------------------------------------------------------------------

三、命令提示
	Cmd方式可以通过 help <指令名字> 来获取命令格式提示
