#include <iostream>
using namespace std;

#include "CacheBlock.h"

CacheBlock::CacheBlock()
{
	Byte_count = 0;
	Addr = NULL;
	BlockNumber = -1;
	Number = 0;

	LastBlock = NULL;
	NextBlock = NULL;

	flags = 0;
}

void CacheBlock::Reset()
{
	Byte_count = 0;
	Addr = NULL;
	BlockNumber = -1;
	Number = 0;

	LastBlock = NULL;
	NextBlock = NULL;

	flags = 0;
}