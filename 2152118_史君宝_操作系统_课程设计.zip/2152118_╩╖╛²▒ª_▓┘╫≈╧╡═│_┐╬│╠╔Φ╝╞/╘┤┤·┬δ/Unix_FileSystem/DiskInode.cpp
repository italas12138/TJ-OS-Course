#include <iostream>
using namespace std;

#include "DiskInode.h"

DiskInode::DiskInode()
{
	this->DiskInode_mode = 0;
	this->DiskInode_nlink = 0;
	this->DiskInode_size = 0;
	memset(DiskInode_addr, 0, sizeof(DiskInode_addr));
	this->DiskInode_atime = 0;
	this->DiskInode_mtime = 0;
}

DiskInode::~DiskInode()
{
}