#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <iostream>
using namespace std;

#include "DiskManager.h"

DiskManager::DiskManager()
{
	DiskPointer = fopen(DiskFileName, "rb+");
}

DiskManager::~DiskManager()
{
	if (DiskPointer != NULL) {
		fclose(DiskPointer);
	}
}

void DiskManager::Reset()
{
	if (DiskPointer != NULL)
		fclose(DiskPointer);
	DiskPointer = fopen(DiskFileName, "rb+");
}

//д���̺���
void DiskManager::write(const uint8* in_buffer, uint32 in_size, int offset, uint32 origin) {
	if (offset >= 0)
		fseek(DiskPointer, offset, origin);
	fwrite(in_buffer, in_size, 1, DiskPointer);
	return;
}
//�����̺���
void DiskManager::read(uint8* out_buffer, uint32 out_size, int offset, uint32 origin) {
	if (offset >= 0)
		fseek(DiskPointer, offset, origin);
	fread(out_buffer, out_size, 1, DiskPointer);
	return;
}

//��龵���ļ��Ƿ����
bool DiskManager::Exists()
{
	return DiskPointer != NULL;
}

//�򿪾����ļ�
void DiskManager::Construct()
{
	DiskPointer = fopen(DiskFileName, "wb+");
	if (DiskPointer == NULL)
		printf("Disk Construct Error!\n");
}