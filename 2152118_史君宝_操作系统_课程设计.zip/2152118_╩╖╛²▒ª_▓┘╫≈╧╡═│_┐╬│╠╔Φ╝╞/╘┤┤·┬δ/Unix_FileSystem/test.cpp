#include <iostream>
using namespace std;

#include "UserCall.h"
#include "System.h"

extern UserCall MyUserCall;


bool Test()
{
	UserCall& User = MyUserCall;

	cout << "ע�⣺�Զ����Բ�������ʽ������" << endl;
	cout << "���ڲ��Գ����е��ļ����д�����������֮ǰ�򿪹��ļ����ܻ�ִ�г����������һ�����Զ�����" << endl;
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /bin" << endl;
	User.userMkDir("/bin");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /etc" << endl;
	User.userMkDir("/etc");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /user" << endl;
	User.userMkDir("/user");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /dev" << endl;
	User.userMkDir("/dev");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "ls" << endl;
	User.userLs();

	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /user/test" << endl;
	User.userMkDir("/user/text");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /user/report" << endl;
	User.userMkDir("/user/report");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "mkdir /user/photo" << endl;
	User.userMkDir("/user/photo");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "ftree /" << endl;
	User.userTree("/");

	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "cd /user/text" << endl;
	User.userCd("/user/text");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fcreate Readme.txt" << endl;
	User.userCreate("Readme.txt");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fopen Readme.txt" << endl;
	User.userOpen("Readme.txt");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fwrite 8 Readme.txt 520" << endl;
	User.userWrite("8", "Readme.txt", "520");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fseek 8 0 begin" << endl;
	User.userSeek("8", "0", "0");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fread 8 ReadmeOut.txt 520" << endl;
	User.userRead("8", "ReadmeOut.txt", "520");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fclose 8" << endl;
	User.userClose("8");

	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "cd /user/report" << endl;
	User.userCd("/user/report");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fcreate Report.pdf" << endl;
	User.userCreate("Report.pdf");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fopen Report.pdf" << endl;
	User.userOpen("Report.pdf");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fwrite 9 Report.pdf 1200000" << endl;
	User.userWrite("9", "Report.pdf", "1200000");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fseek 9 0 begin" << endl;
	User.userSeek("9", "0", "0");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fread 9 ReportOut.pdf 1200000" << endl;
	User.userRead("9", "ReportOut.pdf", "1200000");
	cout << "[ 2152118-SJB-FileSystem" << User.curDirPath << " ]$ " << "fclose 9" << endl;
	User.userClose("9");

	cout << "�Զ����Խ���" << endl << endl;
	return true;
}
