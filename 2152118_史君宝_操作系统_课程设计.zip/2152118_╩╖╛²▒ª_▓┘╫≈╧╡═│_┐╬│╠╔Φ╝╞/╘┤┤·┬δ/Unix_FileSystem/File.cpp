#include <iostream>
using namespace std;

#include "File.h"

File::File()
{
	count = 0;
	inode = NULL;
	offset = 0;
}

File::~File() 
{
}

void File::Reset()
{
	count = 0;
	inode = NULL;
	offset = 0;
}

